﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Xml;

namespace Create_XML_file
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Thread thread1;

        //--------------------TestRun & .ts file & XML file create ------------
        // For Generate TestRun & .ts file & XML file
        private void Create_Click(object sender, EventArgs e)
        {

            CheckForIllegalCrossThreadCalls = false;

            thread1 = new Thread(() => FSF_TestRun(sender, e));
                thread1.Start();

        }

        private void FSF_TestRun(object sender, EventArgs e)
        {

            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            string[] FSF_Spec = null;
            string path = Directory.GetCurrentDirectory() + "\\FSF_Spec\\" ;
            try
            {
                FSF_Spec = Directory.GetFiles(path);
            }
            catch(DirectoryNotFoundException)
            {
                MessageBox.Show("FSF_Spec folder should present with proper FSF spec.");
                return;
            }

            try
            {
                if (FSF_Spec[0] == null)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("FSF spec. excel sheet doccument is not present");
                return;
            }

            string TestRunFolder = Directory.GetCurrentDirectory() + "\\TestRun_Templet\\";

            xlWorkBook = xlapp.Workbooks.Open(FSF_Spec[0]);
            xlWorkSheet = xlWorkBook.ActiveSheet;
            int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;

            button2.Enabled = false;

            // Create failure list from excle sheet
            List<string> AllFailure = new List<string>();
            for (int s = 2; s <= iTotalRows; s++)
            {
                string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                AllFailure.Add(failureName);
            }

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\" ))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\" );

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\XML_File\\" ))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\XML_File\\" );

            string Failure_Ram = null;
            string Failure_Ram_Mem = null;
            string Hex_Num = null;

            XmlTextWriter writer = new XmlTextWriter(Directory.GetCurrentDirectory() + "\\XML_File\\" + "FSF_SW_FACTORY_TESTs.xml", System.Text.Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("root");

            for (int a = 2; a <= iTotalRows; a++)
            {
                string FailureName = (string)(xlWorkSheet.Cells[a, 1] as Excel.Range).Value2;
                string FailurePosition = (string)(xlWorkSheet.Cells[a, 2] as Excel.Range).Value2;
                string Bitmap = (string)(xlWorkSheet.Cells[a, 3].Text.ToString());
                string Word = (string)(xlWorkSheet.Cells[a, 4].Text.ToString());
                string FailureBit = (string)(xlWorkSheet.Cells[a, 5].Text.ToString());
                string DTCValue = (string)(xlWorkSheet.Cells[a, 6].Text.ToString());
                List<string> TestRunFile = new List<string>();
                List<string> TestRun_Rec = new List<string>();
                List<string> TestRun_Mem = new List<string>();
                string DEC_value = null;
                int DEC_Value;
                string FailureBit1 = null;
                var CheckArea = '0';

                if (string.IsNullOrEmpty(FailureName))
                    continue;

                if (string.IsNullOrEmpty(FailurePosition) && string.IsNullOrEmpty(Word))
                    continue;

                if (FailurePosition != null)
                {
                    var chars = FailurePosition.ToCharArray();

                    if (chars[5] == '0')
                        FailureBit = "0001";
                    if (chars[5] == '1')
                        FailureBit = "0002";
                    if (chars[5] == '2')
                        FailureBit = "0004";
                    if (chars[5] == '3')
                        FailureBit = "0008";
                    if (chars[5] == '4')
                        FailureBit = "0010";
                    if (chars[5] == '5')
                        FailureBit = "0020";
                    if (chars[5] == '6')
                        FailureBit = "0040";
                    if (chars[5] == '7')
                        FailureBit = "0080";
                    if (chars[5] == '8')
                        FailureBit = "0100";
                    if (chars[5] == '9')
                        FailureBit = "0200";
                    if (chars[5] == 'A' || chars[5] == 'a')
                        FailureBit = "0400";
                    if (chars[5] == 'B' || chars[5] == 'b')
                        FailureBit = "0800";
                    if (chars[5] == 'C' || chars[5] == 'c')
                        FailureBit = "1000";
                    if (chars[5] == 'D' || chars[5] == 'd')
                        FailureBit = "2000";
                    if (chars[5] == 'E' || chars[5] == 'e')
                        FailureBit = "4000";
                    if (chars[5] == 'F' || chars[5] == 'f')
                        FailureBit = "8000";

                    FailureBit1 = string.Concat("0x", FailureBit);
                    var result = chars.Take(chars.Length - 1);
                    string result1 = string.Join("", result);
                    Hex_Num = string.Concat(result1, FailureBit);

                    DEC_Value = Int32.Parse(Hex_Num.Replace("0x", ""), System.Globalization.NumberStyles.HexNumber);
                    DEC_value = Convert.ToString(DEC_Value);

                    string substr = result1.Substring(result1.Length - 2);
                    int failram_number = Int32.Parse(substr, System.Globalization.NumberStyles.HexNumber);

                    if (chars[2] == '0')
                    {
                        Failure_Ram = "FAIL_RAM" + failram_number.ToString("00");
                        Failure_Ram_Mem = "FAIL_RAM_MEM_" + failram_number.ToString("00");
                    }
                    else
                    {
                        if (chars[2] == '1')
                        {
                            Failure_Ram = "FAIL_RAM_" + "1" + failram_number.ToString("00");
                            Failure_Ram_Mem = "FAIL_RAM_MEM_" + "1" + failram_number.ToString("00");
                        }
                        if (chars[2] == '2')
                        {
                            Failure_Ram = "BUSFAILRAM_" + failram_number.ToString("00");
                            Failure_Ram_Mem = "BUSFAILRAM_" + failram_number.ToString("00");
                        }
                        if (chars[2] == '8')
                        {
                            Failure_Ram = "FAIL_RAM_" + "8" + failram_number.ToString("00");
                            Failure_Ram_Mem = "IPB_FAIL_RAM_MEM" + failram_number.ToString("00");
                        }
                        if (chars[2] == '9')
                        {
                            Failure_Ram = "FAIL_RAM_" + "4" + failram_number.ToString("00");
                            Failure_Ram_Mem = "FAIL_RAM_MEM_" + "4" + failram_number.ToString("00");
                        }
                        if (chars[2] == 'C' || chars[2] == 'c')
                        {
                            Failure_Ram = "FAIL_RAM_" + "3" + failram_number.ToString("00");
                            Failure_Ram_Mem = "FAIL_RAM_MEM_" + "3" + failram_number.ToString("00");
                        }
                    }
                    CheckArea = chars[2];

                }
                else
                {

                    if (FailureBit == "0")
                        FailureBit = "0001";
                    if (FailureBit == "1")
                        FailureBit = "0002";
                    if (FailureBit == "2")
                        FailureBit = "0004";
                    if (FailureBit == "3")
                        FailureBit = "0008";
                    if (FailureBit == "4")
                        FailureBit = "0010";
                    if (FailureBit == "5")
                        FailureBit = "0020";
                    if (FailureBit == "6")
                        FailureBit = "0040";
                    if (FailureBit == "7")
                        FailureBit = "0080";
                    if (FailureBit == "8")
                        FailureBit = "0100";
                    if (FailureBit == "9")
                        FailureBit = "0200";
                    if (FailureBit == "A" || FailureBit == "a")
                        FailureBit = "0400";
                    if (FailureBit == "B" || FailureBit == "b")
                        FailureBit = "0800";
                    if (FailureBit == "C" || FailureBit == "c")
                        FailureBit = "1000";
                    if (FailureBit == "D" || FailureBit == "d")
                        FailureBit = "2000";
                    if (FailureBit == "E" || FailureBit == "e")
                        FailureBit = "4000";
                    if (FailureBit == "F" || FailureBit == "f")
                        FailureBit = "8000";

                    FailureBit1 = string.Concat("0x", FailureBit);
                    int Bitmap1 = Int32.Parse(Bitmap, System.Globalization.NumberStyles.HexNumber);
                    int Word1 = Int32.Parse(Word, System.Globalization.NumberStyles.HexNumber);
                    string name = string.Concat(Bitmap1.ToString("00"), Word1.ToString("00"));
                    name = string.Concat(name, FailureBit);

                    Hex_Num = string.Concat("0x", name);

                    int failram_number1 = Int32.Parse(Word, System.Globalization.NumberStyles.HexNumber);
                    DEC_Value = Int32.Parse(name, System.Globalization.NumberStyles.HexNumber);
                    DEC_value = Convert.ToString(DEC_Value);

                    if (Bitmap == "00" || Bitmap == "0")
                    {
                        Failure_Ram = "FAIL_RAM" + failram_number1.ToString("00");
                        Failure_Ram_Mem = "FAIL_RAM_MEM_" + failram_number1.ToString("00");
                    }
                    else
                    {
                        if (Bitmap == "01" || Bitmap == "1")
                        {
                            Failure_Ram = "FAIL_RAM_" + "1" + failram_number1.ToString("00");
                            Failure_Ram_Mem = "FAIL_RAM_MEM_" + "1" + failram_number1.ToString("00");
                        }
                        if (Bitmap == "02" || Bitmap == "2")
                        {
                            Failure_Ram = "BUSFAILRAM_" + failram_number1.ToString("00");
                            Failure_Ram_Mem = "BUSFAILRAM_" + failram_number1.ToString("00");
                        }
                        if (Bitmap == "08" || Bitmap == "8")
                        {
                            Failure_Ram = "FAIL_RAM_" + "8" + failram_number1.ToString("00");
                            Failure_Ram_Mem = "IPB_FAIL_RAM_MEM" + failram_number1.ToString("00");
                        }
                        if (Bitmap == "09" || Bitmap == "9")
                        {
                            Failure_Ram = "FAIL_RAM_" + "4" + failram_number1.ToString("00");
                            Failure_Ram_Mem = "FAIL_RAM_MEM_" + "4" + failram_number1.ToString("00");
                        }
                        if (Bitmap == "0C" || Bitmap == "0c" || Bitmap == "c" || Bitmap == "C")
                        {
                            Failure_Ram = "FAIL_RAM_" + "3" + failram_number1.ToString("00");
                            Failure_Ram_Mem = "FAIL_RAM_MEM_" + "3" + failram_number1.ToString("00");
                        }
                    }
                }

                // To Generate XML file
                if (CheckArea == '2' || Bitmap == "02" || Bitmap == "2")
                {
                    writer.WriteStartElement("BUS_Bit");
                }
                else if (CheckArea == '9' || Bitmap == "09" || Bitmap == "9")
                {
                    writer.WriteStartElement("FSF4_Bit");
                }
                else
                    writer.WriteStartElement("Failure_Bit");

                writer.WriteStartElement("Failure_name");
                writer.WriteString(FailureName);
                writer.WriteEndElement();

                writer.WriteStartElement("DTC_value");
                writer.WriteString(DTCValue);
                writer.WriteEndElement();

                writer.WriteStartElement("HEX_value");
                writer.WriteString(Hex_Num);
                writer.WriteEndElement();

                writer.WriteStartElement("DEC_value");
                writer.WriteString(DEC_value);
                writer.WriteEndElement();

                writer.WriteStartElement("Failram_value");
                writer.WriteString(Failure_Ram);
                writer.WriteEndElement();

                writer.WriteStartElement("Failram_Mem_value");
                writer.WriteString(Failure_Ram_Mem);
                writer.WriteEndElement();

                writer.WriteStartElement("Failure_Bit_value");
                writer.WriteString(FailureBit1);
                writer.WriteEndElement();

                writer.WriteEndElement();


                // To generate TestRun file.
                string[] files = null;
                try
                {
                    files = Directory.GetFiles(TestRunFolder);
                }
                catch(DirectoryNotFoundException)
                {
                    MessageBox.Show("TestRun_Templet folder should present with TestRun template file");
                    return;
                }

                foreach (string file in files)
                {
                    string name = file.Substring(file.LastIndexOf("\\") + 1);

                    if (name.ToUpper().Contains("_REC") || name.ToUpper().Contains("_MEM"))
                    {
                        if (name.ToUpper().Contains("_REC"))
                        {
                            string[] lines1 = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                            foreach (string line in lines1)
                            {
                                if (line.Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                                    TestRun_Rec.Add("        DVAwr CCP.SetFailureData Abs 50 " + DEC_value);
                                else if (line.Contains("Failure_name"))
                                    TestRun_Rec.Add(line.Replace("Failure_name", FailureName));
                                else
                                    TestRun_Rec.Add(line);
                            }
                            //         int number = a - 1;
                            //         string asString = number.ToString("D" + 4); //"0050"
                            //         string testname = asString + "_" + FailureName;

                            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName + "_Rec", TestRun_Rec);
                        }
                        if (name.ToUpper().Contains("_MEM"))
                        {
                            string[] lines2 = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                            foreach (string line in lines2)
                            {
                                TestRun_Mem.Add(line);
                            }

                            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName + "_Mem", TestRun_Mem);
                        }
                    }
                    else
                    {
                        if (name.EndsWith(".ts"))
                        {
                        }
                        else
                        {
                            string[] lines = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                            foreach (string line in lines)
                            {
                                if (line.Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                                    TestRunFile.Add("        DVAwr CCP.SetFailureData Abs 30 " + DEC_value);
                                else if (line.Contains("Failure_name"))
                                    TestRunFile.Add(line.Replace("Failure_name", FailureName));
                                else
                                    TestRunFile.Add(line);
                            }

                            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName, TestRunFile);
                        }
                    }
                }
            }

            // To generate Test Manager .ts file 
            List<string> TestManagerFile = new List<string>();
            string[] AllTestRun = null;
            try
            {
                AllTestRun = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\TestRun\\" );
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Keep TestRun folder....");
                return;
            }

            string[] files1 = Directory.GetFiles(TestRunFolder);
            int i = 1;

            foreach (string file1 in files1)
            {
                string name1 = file1.Substring(file1.LastIndexOf("\\") + 1);
                if (name1.EndsWith(".ts"))
                {
                    if (i == 1)
                    {
                        string[] lines = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name1));
                        foreach (string line in lines)
                        {
                            TestManagerFile.Add(line);
                        }
                    }
                    foreach (string file in AllTestRun)
                    {
                        string name = file.Substring(file.LastIndexOf("\\") + 1);

                        TestManagerFile.Add("Step." + i + " = TestRun");
                        TestManagerFile.Add("Step." + i + ".Name = MyTestRuns/FSF/" + name);
                        i++;
                    }
                }
            }

            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_DTC_TESTS_SW_FACTORY_PART.ts", TestManagerFile);

            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
            button2.Enabled = true;
            MessageBox.Show("XML File,TestRuns and .ts file are created ! ");
     //       Form1.ActiveForm.Close();
            xlapp.Quit();
        }

        /////////// -> END <- ////////////
    }
}
